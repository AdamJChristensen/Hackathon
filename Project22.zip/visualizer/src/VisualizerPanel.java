
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author bones
 */
public class VisualizerPanel extends javax.swing.JPanel {
    int box_xvals[] = new int[4];
    int box_yvals[] = new int[4];
    int box_zvals[] = new int[4];
    Random rand = new Random();
    double tbox_xvals[] = new double[4];
    double tbox_yvals[] = new double[4];
    double tbox_zvals[] = new double[4];
    int mouseX = 0;
    int mouseY = 0;
    int translationX = 1000;
    int translationY = 100;
    boolean rotate = false;
    boolean draw = true;
    
    double scale = 2.0;
    
    int max = 10000000;
    
    double pointsX[] = new double[max];
    double pointsY[] = new double[max];
    double pointsZ[] = new double[max];
    int digit[] = new int[max];
    double theta = 0.0; //theta is z-axis rot
    double phi = 0.0; //phi is y-axis rot
    double[][] mat={{0.0,0.0,0.0,0.16,0.0,0.0,0.01},{0.85,0.04,-0.04,0.85,0.0,1.6,0.85},{0.2,-0.26,0.23,0.22,0.0,1.6,0.07},{-0.15,0.28,0.26,0.24,0.0,0.44,0.07}};
    /*double[][] mat={{0.0,0.0,0.0,0.16,0.0,0.0,0.01},
                    {0.25,0.04,-0.04,0.85,0.0,1.6,0.85},
                    {0.2,-0.26,0.23,0.22,0.0,1.6,0.07},
                    {-0.15,0.28,0.26,0.24,0.0,0.44,0.07}};*/
    /*double[][] mat={{0.0,0.0,0.0,0.16,0.0,0.0,0.01},
                    {0.85,0.1,-0.04+rand.nextDouble(),0.85,0.0,1.6,0.85},
                    {0.2+rand.nextDouble(),-0.26,0.23,0.22,0.0,1.6,0.07},
                    {-0.15,0.28,0.26,0.24,0.0,0.44,0.07}};*/
    /*double[][] mat={{0.0,0.0,0.0,0.16,0.0,0.0,0.01},
                    {0.85,0.1,-0.04+rand.nextDouble(),0.85,0.0,1.6,0.85},
                    {0.2+rand.nextDouble(),-0.26,0.23+rand.nextDouble(),0.22+rand.nextDouble(),0.0+rand.nextDouble(),1.6,0.07},
                    {-0.15,0.28,0.26,0.24+rand.nextDouble(),0.0+rand.nextDouble(),0.44,0.07}};*/
    int index2 = 0;
    
    double xf = 0.0;
    double yf = 0.0;
    
    double[] origin = new double[2];
    
    /**
     * Creates new form VisualizerPanel
     * @return 
     */
    
    public double[] transformz(double x, double y, double z, double theta){
        double[] dat = new double[3];
        dat[0]=x*Math.cos(theta)-y*Math.sin(theta);
        dat[1]=x*Math.sin(theta)+y*Math.cos(theta);
        dat[2]=z;
        return dat;
    }
    
    public double[] transformy(double x, double y, double z, double phi){
        double[] dat = new double[3];
        dat[0]=x*Math.cos(phi)+z*Math.sin(phi);
        dat[1]=y;
        dat[2]=z*Math.cos(phi)-x*Math.sin(phi);
        return dat;
    }
    
    public double[] transformx(double x, double y, double z, double phi){
        double[] dat = new double[3];
        dat[0]=x;
        dat[1]=y*Math.cos(phi)-z*Math.sin(phi);
        dat[2]=y*Math.sin(phi)+z*Math.cos(phi);
        return dat;
    }
    
    public void buildData(){
        // The name of the file to open.
        String fileName = "C:\\Users\\achri\\Desktop\\Beanz\\gll_psc_v16.reg";

        // This will reference one line at a time
        String line = null;

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);
            int index = 0;
            while((line = bufferedReader.readLine()) != null) {
                //System.out.println(line);
                if(line.contains("fk5;p")){
                    pointsX[index]=Double.valueOf(line.substring(line.indexOf("(")+1, line.indexOf(",")));
                    pointsY[index]=Double.valueOf(line.substring(line.indexOf(",")+1, line.indexOf(")")));
                    index++;
                }
            }   

            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }
    }
    
    public double distance(int a, int b){
        return Math.sqrt((pointsX[a]-pointsX[b])*(pointsX[a]-pointsX[b])+(pointsY[a]-pointsY[b])*(pointsY[a]-pointsY[b]));
    }
    
    public VisualizerPanel() {
        initComponents();
        box_xvals[0]=0;
        box_xvals[1]=360;
        box_xvals[2]=0;
        box_xvals[3]=0;
        box_yvals[0]=0;
        box_yvals[1]=0;
        box_yvals[2]=200;
        box_yvals[3]=0;
        box_zvals[0]=0;
        box_zvals[1]=0;
        box_zvals[2]=0;
        box_zvals[3]=100;
        for(int k = 0; k < 4000; k++){
            pointsX[k]=0.0;
            pointsY[k]=0.0;
            pointsZ[k]=0.0;
        }
        origin[0]=rand.nextDouble();
        origin[1]=rand.nextDouble();
        while(Math.sqrt(origin[0]*origin[0]+origin[1]*origin[1])>1){
            origin[0]=rand.nextDouble();
            origin[1]=rand.nextDouble();
        }
        /*pointsX[0]=0.0377;
        pointsY[0]=65.7517;
        pointsX[1]=11.3494;
        pointsY[1]=21.4459;*/
        //buildData();
        //for(int k = 0; k < 4000; k++){
        //    pointsY[k]+=100.0;
        //}
        //pointsZ[0]=distance(0,1);
        /*for(int k = 0; k < 4000; k++){
            pointsZ[k]=1000.0;
            for(int j = 0; j < k; j++){
                double dis = distance(j,k);
                if(dis<pointsZ[k])
                    pointsZ[k]=dis;
            }
            for(int j = k+1; j < 4000; j++){
                double dis = distance(j,k);
                if(dis<pointsZ[k])
                    pointsZ[k]=dis;
            }
            pointsZ[k]=20.0/pointsZ[k];
        }*/
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                formMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                formMouseReleased(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void formMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMousePressed
        // TODO add your handling code here:
        mouseX = evt.getX();
        mouseY = evt.getY();
    }//GEN-LAST:event_formMousePressed

    private void formMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseReleased
        // TODO add your handling code here:
        translationX -= mouseX-evt.getX();
        translationY -= mouseY-evt.getY();
    }//GEN-LAST:event_formMouseReleased
    
    long zed = System.currentTimeMillis() % 1000;
    long lastframe = System.currentTimeMillis();
    long update = System.currentTimeMillis()+100;
    long secondcounter = System.currentTimeMillis()+1000;
    int frames;
    double fps;
    int distancecounter = 0;
    @Override
    public void paint(Graphics g){
        long diff = System.currentTimeMillis()-lastframe;
        /*if(System.currentTimeMillis()>lastframe+10000){
            lastframe = System.currentTimeMillis();
        }*/
        
        if(System.currentTimeMillis()>secondcounter){
            fps=frames/(double)(System.currentTimeMillis()-secondcounter)*1000.0;
            secondcounter=System.currentTimeMillis();
            frames = 0;
            
        }
        frames++;
        if(rotate){
            //theta=diff*2*Math.PI/14000.0;
            phi=diff*2*Math.PI/27000.0;
        }
        if(theta>=2*Math.PI){
            theta-=2*Math.PI;
        }
        if(phi>=2*Math.PI){
            phi-=2*Math.PI;
        }
        //if(System.currentTimeMillis()>update&&index2<max){
        if(index2<max){
            for(int k = 0; k < 1000; k++){
            double roll = rand.nextDouble();
            if(roll<0.33){
                origin[0]=origin[0]/2.0;
                origin[1]=origin[1]/2.0;
            }
            else if(roll < 0.66){
                origin[0]+=(1-origin[0])/2.0;
                origin[1]=origin[1]/2.0;
            }
            /*else if(roll < 0.75){
                origin[0]+=(0.5-origin[0])/2.0;
                origin[1]=origin[1]/2.0;
            }*/
            else{
                origin[0]+=(0.5-origin[0])/2.0;
                origin[1]+=(Math.sqrt(4)/2.0-origin[1])/2.0;
            }
            pointsX[index2]=origin[0]*100;
            pointsY[index2]=origin[1]*100;
            index2++;
            }
        /*for(int op = 0; op < 500; op++){
        int i;
        double p = rand.nextDouble();
        if(p<=mat[0][6]){
            i=0;
            distancecounter=0;
            digit[index2]=i;
        }
        else if(p <= mat[0][6]+mat[1][6]){
            i=1;
            distancecounter++;
            digit[index2]=i;
        }
        else if(p <= mat[0][6]+mat[1][6]+mat[2][6]){
            i=2;
            digit[index2]=i;
            distancecounter = 0;
        }
        else{
            i=3;
            digit[index2]=i;
            distancecounter = 0;
        }
        double x0 = xf* mat[i][0]+yf*mat[i][1]+mat[i][4];
        yf  = xf * mat[i][2] + yf * mat[i][3] + mat[i][5];
        xf = x0;
        pointsX[index2]=50*xf;
        pointsY[index2]=50*yf;
        pointsZ[index2]=Math.sqrt(pointsX[index2]*pointsX[index2]+pointsY[index2]+pointsY[index2])/5.0;
        pointsZ[index2]+=Math.exp(pointsZ[index2]/10.0);//distancecounter;
        index2++;*/
        //}
        //update = System.currentTimeMillis()+020;
        }
        
        g.setColor(Color.BLACK);
        g.fillRect(0,0,3000,1500);
        g.setColor(Color.WHITE);
        g.setFont(new Font("TimesRoman", Font.PLAIN, 25));
        g.drawString(Integer.toString(index2),10,40);
        g.drawString(Double.toString(fps),10,60);
        g.setColor(Color.GREEN);
        if(draw){
        for(int k = 0; k < max; k++){
            if(pointsX[k]==pointsY[k]&&pointsX[k]==0.0){
                break;
            }
            double[] vals = transformx(scale*pointsX[k],scale*pointsY[k],scale*pointsZ[k],theta);
            double[] vals2 = transformy(vals[0],vals[1],vals[2],phi);
            //double z = pointsZ[k]*8;
            //g.setColor(Color.GREEN);
            /*if(z>255.0){
                g.setColor(new Color(128,255,128));
            }
            else{
                g.setColor(new Color(255-(int)z,255,255-(int)z));
            }*/
            //if(digit)
            
            g.drawLine(translationX+(int)vals2[0],translationY+(int)vals2[1],translationX+(int)vals2[0],translationY+(int)vals2[1]);
        }
        }  
        
        for(int k = 0; k < 4; k++){ //z-axis rotation
            double[] vals = transformx(scale*box_xvals[k],scale*box_yvals[k],scale*box_zvals[k],theta);
            tbox_xvals[k]=vals[0];
            tbox_yvals[k]=vals[1];
            tbox_zvals[k]=vals[2];
            /*tbox_xvals[k]=(int) (box_xvals[k]*Math.cos(theta)-box_yvals[k]*Math.sin(theta));
            tbox_yvals[k]=(int) (box_xvals[k]*Math.sin(theta)+box_yvals[k]*Math.cos(theta));
            tbox_zvals[k]=box_zvals[k];*/
        }
        for(int k = 0; k < 4; k++){
            double[] vals = transformy(tbox_xvals[k],tbox_yvals[k],tbox_zvals[k],phi);
            tbox_xvals[k]=vals[0];
            tbox_yvals[k]=vals[1];
            tbox_zvals[k]=vals[2];
            /*tbox_xvals[k]=(int) (tbox_xvals[k]*Math.cos(phi)+tbox_zvals[k]*Math.sin(phi));
            tbox_yvals[k]=tbox_yvals[k];
            tbox_zvals[k]=(int) (tbox_zvals[k]*Math.cos(phi)-tbox_xvals[k]*Math.sin(phi));*/
        }
        g.setColor(Color.RED);
        g.drawLine(translationX+(int)tbox_xvals[0],translationY+(int)tbox_yvals[0],translationX+(int)tbox_xvals[1],translationY+(int)tbox_yvals[1]);
        g.setColor(Color.BLUE);
        g.drawLine(translationX+(int)tbox_xvals[0],translationY+(int)tbox_yvals[0],translationX+(int)tbox_xvals[2],translationY+(int)tbox_yvals[2]);
        g.setColor(Color.YELLOW);
        g.drawLine(translationX+(int)tbox_xvals[0],translationY+(int)tbox_yvals[0],translationX+(int)tbox_xvals[3],translationY+(int)tbox_yvals[3]);
        repaint();
    }
    
    public void clickLeft(){
        phi-=Math.PI/16.0;
    }
    public void clickRight(){
        phi+=Math.PI/16.0;
    }
    public void clickUp(){
        theta-=Math.PI/16.0;
    }
    public void clickDown(){
        theta+=Math.PI/16.0;
    }
    public void zoomP(){
        scale+=0.25;
    }
    public void zoomN(){
        scale-=0.25;
    }
    
    public void flip(){
        rotate = !rotate;
    }
    public void flip2(){
        draw = !draw;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
